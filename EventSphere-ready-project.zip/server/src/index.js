import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'node:crypto';
import QRCode from 'qrcode';
import db from './db.js';
import { sendRegistrationEmail } from './mailer.js';

const app=express();
const PORT=process.env.PORT || 4000;
const SECRET=process.env.JWT_SECRET || 'development-only-change-me';
app.use(cors({origin:process.env.CLIENT_ORIGIN || 'http://localhost:5173'}));
app.use(express.json({limit:'1mb'}));
const publicUser=u=>({id:u.id,name:u.name,email:u.email,role:u.role});
function auth(req,res,next){
 const token=(req.headers.authorization||'').replace(/^Bearer /,'');
 try{req.user=jwt.verify(token,SECRET);next();}catch{return res.status(401).json({error:'Please log in again.'});}
}
function organizer(req,res,next){if(req.user.role!=='organizer')return res.status(403).json({error:'Organizer access required.'});next();}
app.get('/api/health',(_,res)=>res.json({ok:true,name:'EventSphere API'}));

app.post('/api/auth/register',async(req,res)=>{
 const {name,email,password}=req.body||{};
 if(!name?.trim()||!email?.trim()||!password||password.length<8)return res.status(400).json({error:'Name, email and password (8+ characters) are required.'});
 try{
  const hash=await bcrypt.hash(password,10);
  const info=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run(name.trim(),email.trim().toLowerCase(),hash,'attendee');
  const user=publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid));
  const token=jwt.sign(user,SECRET,{expiresIn:'7d'});res.status(201).json({token,user});
 }catch(e){res.status(409).json({error:e.code==='SQLITE_CONSTRAINT_UNIQUE'?'Email is already registered.':'Could not create account.'});}
});
app.post('/api/auth/login',async(req,res)=>{
 const {email,password}=req.body||{};
 const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').trim().toLowerCase());
 if(!u||!await bcrypt.compare(password||'',u.password_hash))return res.status(401).json({error:'Invalid email or password.'});
 const user=publicUser(u);res.json({token:jwt.sign(user,SECRET,{expiresIn:'7d'}),user});
});
app.get('/api/events',(req,res)=>{
 const events=db.prepare(`SELECT e.*,u.name organizer_name,
 (SELECT COUNT(*) FROM registrations r WHERE r.event_id=e.id) registrations
 FROM events e JOIN users u ON u.id=e.organizer_id ORDER BY e.event_date ASC`).all();
 res.json(events);
});
app.post('/api/events',auth,organizer,(req,res)=>{
 const {title,description='',venue,event_date,capacity}=req.body||{};
 if(!title?.trim()||!venue?.trim()||!event_date||!Number.isInteger(Number(capacity))||Number(capacity)<1)
  return res.status(400).json({error:'Title, venue, date and a positive capacity are required.'});
 const info=db.prepare('INSERT INTO events(title,description,venue,event_date,capacity,organizer_id) VALUES(?,?,?,?,?,?)')
 .run(title.trim(),description,venue.trim(),event_date,Number(capacity),req.user.id);
 res.status(201).json(db.prepare('SELECT * FROM events WHERE id=?').get(info.lastInsertRowid));
});
app.delete('/api/events/:id',auth,organizer,(req,res)=>{
 const event=db.prepare('SELECT * FROM events WHERE id=?').get(req.params.id);
 if(!event)return res.status(404).json({error:'Event not found.'});
 if(event.organizer_id!==req.user.id)return res.status(403).json({error:'You can only delete your own events.'});
 db.prepare('DELETE FROM registrations WHERE event_id=?').run(event.id);db.prepare('DELETE FROM events WHERE id=?').run(event.id);
 res.json({ok:true});
});
app.post('/api/events/:id/register',auth,(req,res)=>{
 if(req.user.role!=='attendee')return res.status(400).json({error:'Only attendee accounts can register.'});
 const event=db.prepare('SELECT * FROM events WHERE id=?').get(req.params.id);
 if(!event)return res.status(404).json({error:'Event not found.'});
 const count=db.prepare('SELECT COUNT(*) n FROM registrations WHERE event_id=?').get(event.id).n;
 if(count>=event.capacity)return res.status(409).json({error:'This event is full.'});
 const ticket_code=randomUUID();
 try{
  db.prepare('INSERT INTO registrations(event_id,user_id,ticket_code) VALUES(?,?,?)').run(event.id,req.user.id,ticket_code);
  const user=db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  sendRegistrationEmail(user.email,user.name,event.title,ticket_code).catch(e=>console.error('Email failed:',e.message));
  res.status(201).json({ticket_code,event_title:event.title});
 }catch(e){res.status(409).json({error:'You are already registered for this event.'});}
});
app.get('/api/my-tickets',auth,(req,res)=>{
 const rows=db.prepare(`SELECT r.id,r.ticket_code,r.checked_in,r.registered_at,e.title,e.venue,e.event_date
 FROM registrations r JOIN events e ON e.id=r.event_id WHERE r.user_id=? ORDER BY e.event_date`).all(req.user.id);
 res.json(rows);
});
app.get('/api/tickets/:code/qr',auth,async(req,res)=>{
 const ticket=db.prepare(`SELECT r.*,e.title FROM registrations r JOIN events e ON e.id=r.event_id
 WHERE r.ticket_code=? AND r.user_id=?`).get(req.params.code,req.user.id);
 if(!ticket)return res.status(404).json({error:'Ticket not found.'});
 res.json({qr:await QRCode.toDataURL(ticket.ticket_code),ticket_code:ticket.ticket_code});
});
app.get('/api/analytics',auth,organizer,(req,res)=>{
 const events=db.prepare(`SELECT e.id,e.title,e.capacity,COUNT(r.id) registrations,
 SUM(CASE WHEN r.checked_in=1 THEN 1 ELSE 0 END) attendance
 FROM events e LEFT JOIN registrations r ON r.event_id=e.id
 WHERE e.organizer_id=? GROUP BY e.id ORDER BY e.event_date`).all(req.user.id);
 res.json({events,totalEvents:events.length,totalRegistrations:events.reduce((s,e)=>s+e.registrations,0),
 totalAttendance:events.reduce((s,e)=>s+(e.attendance||0),0)});
});
app.post('/api/check-in',auth,organizer,(req,res)=>{
 const {ticket_code}=req.body||{};
 const ticket=db.prepare(`SELECT r.id,r.checked_in,e.organizer_id,e.title FROM registrations r
 JOIN events e ON e.id=r.event_id WHERE r.ticket_code=?`).get(ticket_code);
 if(!ticket)return res.status(404).json({error:'Ticket code is invalid.'});
 if(ticket.organizer_id!==req.user.id)return res.status(403).json({error:'This ticket belongs to another organizer.'});
 if(ticket.checked_in)return res.status(409).json({error:'Ticket has already been checked in.'});
 db.prepare('UPDATE registrations SET checked_in=1 WHERE id=?').run(ticket.id);
 res.json({ok:true,message:`Checked in successfully for ${ticket.title}.`});
});
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Unexpected server error.'});});
app.listen(PORT,()=>console.log(`EventSphere API listening at http://localhost:${PORT}`));