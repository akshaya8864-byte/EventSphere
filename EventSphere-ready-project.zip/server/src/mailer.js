import nodemailer from 'nodemailer';
export async function sendRegistrationEmail(to, name, eventTitle, ticketCode) {
 if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
   console.log(`[email skipped: SMTP not configured] ticket ${ticketCode} for ${to}`);
   return;
 }
 const transport = nodemailer.createTransport({
   host:process.env.SMTP_HOST, port:Number(process.env.SMTP_PORT || 587),
   secure:Number(process.env.SMTP_PORT)===465,
   auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}
 });
 await transport.sendMail({from:process.env.MAIL_FROM || process.env.SMTP_USER,to,
   subject:`Your EventSphere ticket: ${eventTitle}`,
   text:`Hi ${name}, you are registered for ${eventTitle}. Ticket code: ${ticketCode}`});
}