import 'dotenv/config';
import bcrypt from 'bcryptjs';
import db from './db.js';
const email='organizer@eventsphere.local';
const existing=db.prepare('SELECT id FROM users WHERE email=?').get(email);
if(!existing){
 const hash=bcrypt.hashSync('EventSphere123!',10);
 const info=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'organizer')").run('Demo Organizer',email,hash);
 db.prepare('INSERT INTO events(title,description,venue,event_date,capacity,organizer_id) VALUES(?,?,?,?,?,?)')
 .run('Campus Tech Summit','A sample technology and innovation event.','Main Auditorium','2027-01-15T10:00',200,info.lastInsertRowid);
 console.log('Seeded organizer and sample event.');
}else console.log('Seed account already exists.');
db.close();