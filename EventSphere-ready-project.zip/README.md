# EventSphere — Smart Event Management & Analytics Platform

A runnable MVP with React + Vite frontend, Express API, SQLite persistence, JWT authentication, organizer/attendee roles, event management, registrations, QR tickets, check-in, and basic analytics.

## Requirements
- Node.js 20 LTS or newer (includes npm)
- VS Code
- Internet for the first dependency installation
- Optional: SMTP credentials for real email notifications. Without SMTP, registrations still work and the server logs a notice.

## VS Code extensions
Recommended: **ESLint** (dbaeumer.vscode-eslint), **Prettier** (esbenp.prettier-vscode), **JavaScript and TypeScript Nightly** is optional. No extension is required to run the app; Node.js is required.

## Run on Windows
1. Extract this folder and open **EventSphere** in VS Code.
2. Open Terminal → New Terminal.
3. Check `node -v` and `npm -v`. If missing, install Node.js LTS from https://nodejs.org/ and restart VS Code.
4. Run these commands in the project root terminal:
   ```bash
   npm run install-all
   ```
5. Copy `server/.env.example` to `server/.env`. Change `JWT_SECRET` to a long random value. SMTP is optional.
6. Start both apps:
   ```bash
   npm run dev
   ```
7. Open http://localhost:5173

The API runs at http://localhost:4000. The SQLite database is created automatically at `server/eventsphere.db`.

## First use
- Register an account. The first account is an attendee.
- To create events, set `ROLE=organizer` is not a registration option by design. For local development, promote a user in SQLite or use the seed script:
  ```bash
  npm --prefix server run seed
  ```
  Seed login: `organizer@eventsphere.local` / `EventSphere123!`
- Register for an event as an attendee; your ticket QR appears under My tickets.
- Organizers can see event analytics and validate/check in tickets from the organizer dashboard.

## Environment variables
See `server/.env.example`. SMTP settings are optional. For production, use a strong JWT secret, HTTPS, a managed database, rate limiting, and a real email provider.

## Important
This is an educational MVP, not a production-hardened deployment. Do not expose it publicly without reviewing authentication, authorization, rate limiting, email delivery, backups, and privacy requirements.
